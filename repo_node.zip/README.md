#nuestro primer proyecto


#para listado de cursos:
node principal 
#para ayuda a inscribir usuario al curso:
node principal inscribir
#para inscribir usuario al curso:
node principal inscribir -i=## -n=## -x=##
#para inscribir usuario al curso:
#luego abrir el navegador y ver resultado
http://localhost:3000